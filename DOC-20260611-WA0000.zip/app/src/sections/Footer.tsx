import { ShoppingBag, MessageCircle, Mail, MapPin, Heart } from "lucide-react";

export function Footer() {
  return (
    <footer id="footer" className="bg-slate-900 text-slate-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
          {/* Brand */}
          <div>
            <div className="flex items-center gap-2 mb-4">
              <div className="w-9 h-9 bg-[#25D366] rounded-xl flex items-center justify-center">
                <ShoppingBag size={18} className="text-white" />
              </div>
              <span className="font-bold text-xl text-white">MiTienda</span>
            </div>
            <p className="text-slate-400 text-sm leading-relaxed mb-6">
              Tu tienda de confianza para encontrar los mejores productos al mejor precio.
              Compra fácil y seguro por WhatsApp.
            </p>
            <a
              href="https://wa.me/TU_NUMERO"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 bg-[#25D366] hover:bg-[#1ebe5d] text-white px-5 py-2.5 rounded-xl text-sm font-medium transition-all hover:shadow-lg hover:shadow-[#25D366]/25"
            >
              <MessageCircle size={16} />
              Escribir por WhatsApp
            </a>
          </div>

          {/* Links */}
          <div>
            <h4 className="text-white font-semibold mb-4">Enlaces</h4>
            <div className="flex flex-col gap-3">
              {[
                { label: "Inicio", id: "hero" },
                { label: "Productos", id: "products" },
              ].map((link) => (
                <button
                  key={link.id}
                  onClick={() =>
                    document.getElementById(link.id)?.scrollIntoView({ behavior: "smooth" })
                  }
                  className="text-left text-slate-400 hover:text-[#25D366] text-sm transition-colors w-fit"
                >
                  {link.label}
                </button>
              ))}
            </div>
          </div>

          {/* Contact */}
          <div>
            <h4 className="text-white font-semibold mb-4">Contacto</h4>
            <div className="flex flex-col gap-4">
              <div className="flex items-start gap-3">
                <MessageCircle size={16} className="text-[#25D366] mt-0.5 shrink-0" />
                <div>
                  <p className="text-sm font-medium text-white">WhatsApp</p>
                  <p className="text-sm text-slate-400">+XX XXX XXX XXXX</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <Mail size={16} className="text-[#25D366] mt-0.5 shrink-0" />
                <div>
                  <p className="text-sm font-medium text-white">Email</p>
                  <p className="text-sm text-slate-400">hola@mitienda.com</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <MapPin size={16} className="text-[#25D366] mt-0.5 shrink-0" />
                <div>
                  <p className="text-sm font-medium text-white">Ubicación</p>
                  <p className="text-sm text-slate-400">Envíos a todo el país</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom */}
        <div className="border-t border-slate-800 mt-12 pt-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-slate-500 text-sm">
            &copy; 2026 MiTienda. Todos los derechos reservados.
          </p>
          <p className="text-slate-500 text-sm flex items-center gap-1">
            Hecho con <Heart size={13} className="text-rose-500 fill-rose-500" /> para ti
          </p>
        </div>
      </div>
    </footer>
  );
}
