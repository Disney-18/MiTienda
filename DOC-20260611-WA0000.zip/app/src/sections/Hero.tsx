import { ArrowDown, Zap, Shield, Truck } from "lucide-react";

export function Hero() {
  const scrollToProducts = () => {
    document.getElementById("products")?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <section
      id="hero"
      className="relative min-h-screen flex items-center justify-center overflow-hidden bg-slate-900"
    >
      {/* Background Pattern */}
      <div className="absolute inset-0">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-slate-800 via-slate-900 to-black" />
        <div className="absolute inset-0 opacity-20">
          <div
            className="absolute inset-0"
            style={{
              backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.08'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
            }}
          />
        </div>
        {/* Animated blobs */}
        <div className="absolute top-1/4 -left-32 w-96 h-96 bg-[#25D366]/20 rounded-full blur-3xl animate-pulse" />
        <div className="absolute bottom-1/4 -right-32 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl animate-pulse" style={{ animationDelay: "1s" }} />
      </div>

      <div className="relative z-10 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center pt-20">
        <div className="inline-flex items-center gap-2 bg-white/10 backdrop-blur-sm border border-white/10 rounded-full px-4 py-2 mb-8 animate-fadeIn">
          <Zap size={14} className="text-[#25D366]" />
          <span className="text-white/80 text-sm font-medium">Envío gratis en pedidos mayores a $50</span>
        </div>

        <h1 className="text-4xl sm:text-5xl md:text-7xl font-bold text-white leading-tight mb-6 animate-fadeIn">
          Compra fácil por{" "}
          <span className="text-[#25D366]">WhatsApp</span>
        </h1>

        <p className="text-lg sm:text-xl text-slate-400 max-w-2xl mx-auto mb-10 leading-relaxed animate-fadeIn" style={{ animationDelay: "0.15s" }}>
          Productos seleccionados con los mejores precios. Sin registros, sin complicaciones.
          Solo elige, escribe y recibe.
        </p>

        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-16 animate-fadeIn" style={{ animationDelay: "0.3s" }}>
          <button
            onClick={scrollToProducts}
            className="flex items-center gap-2 bg-[#25D366] hover:bg-[#1ebe5d] text-white px-8 py-4 rounded-2xl font-semibold text-lg transition-all hover:shadow-xl hover:shadow-[#25D366]/25 active:scale-95"
          >
            Ver Productos
            <ArrowDown size={18} />
          </button>
          <a
            href="https://wa.me/TU_NUMERO"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-2 bg-white/10 hover:bg-white/20 text-white backdrop-blur-sm border border-white/10 px-8 py-4 rounded-2xl font-semibold text-lg transition-all"
          >
            Escríbenos
          </a>
        </div>

        {/* Features */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 max-w-3xl mx-auto animate-fadeIn" style={{ animationDelay: "0.45s" }}>
          {[
            { icon: Truck, label: "Envío Rápido", desc: "2-3 días hábiles" },
            { icon: Shield, label: "Pago Seguro", desc: "Contra entrega" },
            { icon: Zap, label: "Atención 24/7", desc: "Por WhatsApp" },
          ].map((feature, i) => (
            <div
              key={i}
              className="flex items-center gap-4 bg-white/5 backdrop-blur-sm border border-white/10 rounded-2xl px-5 py-4"
            >
              <div className="w-10 h-10 bg-[#25D366]/20 rounded-xl flex items-center justify-center shrink-0">
                <feature.icon size={20} className="text-[#25D366]" />
              </div>
              <div className="text-left">
                <div className="text-white font-medium text-sm">{feature.label}</div>
                <div className="text-slate-400 text-xs">{feature.desc}</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Scroll Indicator */}
      <button
        onClick={scrollToProducts}
        className="absolute bottom-8 left-1/2 -translate-x-1/2 text-white/40 hover:text-white/70 transition-colors animate-bounce"
      >
        <ArrowDown size={24} />
      </button>
    </section>
  );
}
