import { Navbar } from "@/sections/Navbar";
import { Hero } from "@/sections/Hero";
import { Products } from "@/sections/Products";
import { Footer } from "@/sections/Footer";
import { ToastContainer } from "@/components/Toast";
import { useToast } from "@/hooks/useToast";
import type { Product } from "@/data/products";

function App() {
  const { toasts, addToast, removeToast } = useToast();

  const handleOrder = (product: Product) => {
    addToast(`¡Producto "${product.name}" añadido! Redirigiendo a WhatsApp...`, "success");
  };

  return (
    <div className="min-h-screen bg-white font-sans antialiased">
      <Navbar />
      <Hero />
      <Products onOrder={handleOrder} />
      <Footer />
      <ToastContainer toasts={toasts} onRemove={removeToast} />
    </div>
  );
}

export default App;
