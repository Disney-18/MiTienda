import { useState } from "react";
import { ShoppingCart, MessageCircle, Eye, Star } from "lucide-react";
import type { Product } from "@/data/products";
import { useInView } from "@/hooks/useInView";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";

interface ProductCardProps {
  product: Product;
  index: number;
  onOrder: (product: Product) => void;
}

export function ProductCard({ product, index, onOrder }: ProductCardProps) {
  const [isHovered, setIsHovered] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const { ref, inView } = useInView<HTMLDivElement>();

  const whatsappLink = `https://wa.me/TU_NUMERO?text=${encodeURIComponent(
    `Hola! Me interesa comprar el *${product.name}* - Precio: $${product.price.toFixed(2)}`
  )}`;

  const badgeColors: Record<string, string> = {
    "Más Vendido": "bg-amber-500",
    "Nuevo": "bg-emerald-500",
    "Oferta": "bg-rose-500",
  };

  return (
    <>
      <div
        ref={ref}
        className={`group relative bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-xl transition-all duration-500 border border-slate-100 ${
          inView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
        }`}
        style={{ transitionDelay: `${index * 80}ms` }}
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
      >
        {/* Badge */}
        {product.badge && (
          <div
            className={`absolute top-3 left-3 z-10 ${badgeColors[product.badge] || "bg-slate-800"} text-white text-xs font-semibold px-3 py-1 rounded-full`}
          >
            {product.badge}
          </div>
        )}

        {/* Image Container */}
        <div className="relative overflow-hidden bg-slate-50 aspect-[4/3]">
          <img
            src={product.image}
            alt={product.name}
            className={`w-full h-full object-cover transition-transform duration-700 ${
              isHovered ? "scale-110" : "scale-100"
            }`}
          />
          <div
            className={`absolute inset-0 bg-black/40 flex items-center justify-center gap-3 transition-opacity duration-300 ${
              isHovered ? "opacity-100" : "opacity-0"
            }`}
          >
            <button
              onClick={() => setShowModal(true)}
              className="w-11 h-11 bg-white rounded-full flex items-center justify-center text-slate-800 hover:bg-slate-100 transition-transform hover:scale-110 shadow-lg"
              title="Ver detalles"
            >
              <Eye size={18} />
            </button>
            <button
              onClick={() => onOrder(product)}
              className="w-11 h-11 bg-[#25D366] rounded-full flex items-center justify-center text-white hover:bg-[#1ebe5d] transition-transform hover:scale-110 shadow-lg"
              title="Comprar"
            >
              <MessageCircle size={18} />
            </button>
          </div>
        </div>

        {/* Info */}
        <div className="p-5">
          <div className="flex items-center gap-1 mb-2">
            {[...Array(5)].map((_, i) => (
              <Star
                key={i}
                size={12}
                className={i < 4 ? "text-amber-400 fill-amber-400" : "text-slate-200 fill-slate-200"}
              />
            ))}
            <span className="text-xs text-slate-400 ml-1">(24)</span>
          </div>

          <h3 className="font-semibold text-slate-800 text-lg mb-1 leading-tight">
            {product.name}
          </h3>
          <p className="text-slate-500 text-sm mb-4 line-clamp-2">{product.description}</p>

          <div className="flex items-center justify-between">
            <span className="text-2xl font-bold text-slate-900">
              ${product.price.toFixed(2)}
            </span>
            <a
              href={whatsappLink}
              target="_blank"
              rel="noopener noreferrer"
              onClick={(e) => {
                e.preventDefault();
                onOrder(product);
                window.open(whatsappLink, "_blank");
              }}
              className="flex items-center gap-2 bg-[#25D366] hover:bg-[#1ebe5d] text-white px-4 py-2.5 rounded-xl font-medium text-sm transition-all duration-300 hover:shadow-lg hover:shadow-[#25D366]/30 active:scale-95"
            >
              <ShoppingCart size={16} />
              Comprar
            </a>
          </div>
        </div>
      </div>

      {/* Product Detail Modal */}
      <Dialog open={showModal} onOpenChange={setShowModal}>
        <DialogContent className="sm:max-w-lg p-0 overflow-hidden rounded-2xl border-0">
          <div className="aspect-video w-full overflow-hidden bg-slate-50">
            <img
              src={product.image}
              alt={product.name}
              className="w-full h-full object-cover"
            />
          </div>
          <div className="p-6">
            <DialogHeader>
              <DialogTitle className="text-2xl font-bold text-slate-900">
                {product.name}
              </DialogTitle>
            </DialogHeader>
            <div className="flex items-center gap-1 mt-2 mb-3">
              {[...Array(5)].map((_, i) => (
                <Star
                  key={i}
                  size={14}
                  className={i < 4 ? "text-amber-400 fill-amber-400" : "text-slate-200 fill-slate-200"}
                />
              ))}
              <span className="text-sm text-slate-400 ml-1">128 valoraciones</span>
            </div>
            <p className="text-slate-600 mb-4 leading-relaxed">{product.description}</p>
            <div className="flex items-center gap-3 mb-6">
              <span className="text-3xl font-bold text-slate-900">${product.price.toFixed(2)}</span>
              <span className="text-sm text-slate-400 line-through">${(product.price * 1.3).toFixed(2)}</span>
              <span className="bg-rose-100 text-rose-600 text-xs font-bold px-2 py-1 rounded-lg">-30%</span>
            </div>
            <a
              href={whatsappLink}
              target="_blank"
              rel="noopener noreferrer"
              onClick={(e) => {
                e.preventDefault();
                onOrder(product);
                window.open(whatsappLink, "_blank");
                setShowModal(false);
              }}
              className="flex items-center justify-center gap-3 w-full bg-[#25D366] hover:bg-[#1ebe5d] text-white py-3.5 rounded-xl font-semibold text-base transition-all duration-300 hover:shadow-lg hover:shadow-[#25D366]/30"
            >
              <MessageCircle size={20} />
              Comprar por WhatsApp
            </a>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
