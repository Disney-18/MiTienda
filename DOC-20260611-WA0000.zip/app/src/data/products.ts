export interface Product {
  id: number;
  name: string;
  description: string;
  price: number;
  image: string;
  category: string;
  badge?: string;
}

export const categories = [
  { id: "all", label: "Todos" },
  { id: "tech", label: "Tecnología" },
  { id: "audio", label: "Audio" },
  { id: "lifestyle", label: "Estilo de Vida" },
  { id: "accessories", label: "Accesorios" },
];

export const products: Product[] = [
  {
    id: 1,
    name: "Auriculares Pro Wireless",
    description: "Sonido envolvente con cancelación activa de ruido. 30 horas de batería.",
    price: 89.99,
    image: "/images/producto1.jpg",
    category: "audio",
    badge: "Más Vendido",
  },
  {
    id: 2,
    name: "SmartWatch Active",
    description: "Monitorea tu salud, fitness y notificaciones. Resistente al agua.",
    price: 129.99,
    image: "/images/producto2.jpg",
    category: "tech",
    badge: "Nuevo",
  },
  {
    id: 3,
    name: "Speaker Bluetooth Elite",
    description: "Sonido 360° con graves potentes. 20 horas de reproducción.",
    price: 59.99,
    image: "/images/producto3.jpg",
    category: "audio",
  },
  {
    id: 4,
    name: "Soporte Laptop Aluminio",
    description: "Diseño ergonómico ajustable. Compatible con portátiles hasta 17\".",
    price: 34.99,
    image: "/images/producto4.jpg",
    category: "tech",
    badge: "Oferta",
  },
  {
    id: 5,
    name: "Cartera Premium Piel",
    description: "Cuero genuino con compartimento para tarjetas y billetes.",
    price: 44.99,
    image: "/images/producto5.jpg",
    category: "accessories",
  },
  {
    id: 6,
    name: "Taza Cerámica Artisan",
    description: "Cerámica artesanal con asa de madera. 350ml de capacidad.",
    price: 19.99,
    image: "/images/producto6.jpg",
    category: "lifestyle",
  },
];
